<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("conn.php");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

    <!--Add cnd link are add here-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <!--Add css links are add here-->
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!--Add section start here-->

    <div class="container d-flex flex-column justify-column-center">
        <div class="row my-5 bg-light">
            <div class="col-lg-12">
                    <h3 class="text-center my-4 h1">Project lists</h3>

                    <a class="btn btn-primary" href="add.php" role="button">Add Project</a>
                    <hr>

                    <?php

                    $currentPage = isset($_GET["page"]) ? intval($_GET["page"]) :
                     $currentPage = 1;

                    $limit = 5;
                    $offset = ($currentPage - 1) * $limit;
                    
                    $sql = "SELECT * FROM transactions LIMIT $limit OFFSET $offset ";
                    $res = mysqli_query($conn, $sql);

                    ?>

                    <div class="table-responsive">
                        <table class="table ">
                            <thead>
                                <tr class="text-center">
                                    <th scope="col">SL.</th>
                                    <th scope="col">Project</th>
                                    <th scope="col">Transaction</th>
                                    <th scope="col">Income</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Currency</th>
                                    <th scope="col">View</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>                                                                 
                                </tr>
                            </thead>
                            <tbody>

                            <?php

                             $serialNumber = ($limit * ($currentPage-1))+1;


                            while ($row = mysqli_fetch_assoc($res)) {

                            ?>
                                <tr class="text-center">
                                    <th scope="row"><?php echo $serialNumber;?></th>
                                    <td><?php echo $row['project'];?></td>
                                    <td><?php echo $row['transaction_type'];?></td>
                                    <td><?php echo $row['income_source'];?></td>
                                    <td><?php echo $row['amount'];?></td>
                                    <td><?php echo $row['currency'];?></td>
                                    <td><a class="text-success" href="view.php?id=<?php  echo $row['id']; ?>"><i class="fa-solid fa-eye"></i></a></td>
                                    <td><a class="text-warning" href="add.php?id=<?php echo $row['id'];?>"><i class="fa-solid fa-pen-to-square"></i></a></td>
                                    <td><a class="text-danger" href="delete.php?id=<?php echo $row['id'];?>"><i class="fa-solid fa-trash"></i></a></td>                                    
                                </tr>
                                </tr>

                            <?php 

                            $serialNumber++;

                            }  

                            ?>    
                            </tbody>
                        </table>
                        
                        <div class="d-flex justify-content-between gap-2 py-3 ">

                        <div>
                            <?php 
                            $total = mysqli_query($conn, "SELECT * FROM transactions");
                            $totalRow = mysqli_num_rows($total);

                            ?>
                            <p>Showing 1 to <?php echo $totalRow ?> of <?php echo $totalRow ?> enteries</p>
                        </div>

                        <div >
                            <?php

                            $total = mysqli_query($conn, "SELECT * FROM transactions");
                            $totalRow = mysqli_num_rows($total);

                            $totalPage = ceil($totalRow / $limit);

                            if ($currentPage > $totalPage) {
                                $currentPage = $totalPage;
                            }

                            for ($i = 1; $i <= $totalPage; $i++) {
                                if ($currentPage == $i) {
                                    echo "<a class='btn btn-success' href='?page=$i'>$i</a>";
                                } else {
                                    echo "<a class='btn btn-primary' href='?page=$i'>$i</a>";
                                }
                            }

                          ?>

                        </div>

                         
                    </div>
                    
            </div>
        </div>
    </div>                


    <!--Add boostrap stript links add here-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>    
</body>
</html>