<?php

$conn = mysqli_connect('localhost', 'admin', 'mysql123', 'Test');

?>