<?php

include("conn.php");

if(isset($_GET["id"])){
    
    $id = $_GET["id"];

    $sql = "DELETE FROM transactions WHERE id = '$id'";
    $res = mysqli_query($conn, $sql);

    if($res) {
        header("Location:index.php");
    }
}

?>