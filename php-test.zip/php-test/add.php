<?php

include("conn.php");


if (isset($_POST["submit"])) {

    $id = $_POST["id"];
    $project = $_POST["project"];
    $transaction = $_POST["transaction"];
    $income = $_POST["income"];
    $amount = $_POST["amount"];
    $currency = $_POST["currency"];




    if($id !== ""){
        $sql = "UPDATE `transactions` SET `project`='$project',`transaction_type`='$transaction',`income_source`='$income',`amount`='$amount',`currency`='$currency' WHERE id = '$id'";
    } else {
        $sql = "INSERT INTO transactions (project, 	transaction_type, income_source, amount, currency) VALUES ('$project', '$transaction', '$income', '$amount', '$currency')";
    }

    $res = mysqli_query($conn, $sql);

    if ($res) {
        header("Location:index.php");
    }
}


if (isset($_GET["id"])) {

    $id = $_GET["id"];

    $project = $transaction = $income = $amount = $currency = "";

    $sql = "SELECT * FROM transactions WHERE id = '$id'";
    $res = mysqli_query($conn, $sql);

    if ($res) {
        $row = mysqli_fetch_array($res);
        $id = $row["id"];
        $project = $row["project"];
        $transaction = $row["transaction_type"];
        $income = $row["income_source"];
        $amount = $row["amount"];
        $currency = $row["currency"];
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


    <!--Add cnd link are add here-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <!--Add css links are add here-->
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!--Add section start here-->
    <div class="container d-flex flex-column justify-column-center">
        <div class="row my-5 bg-light">
            <div class="col-lg-12">
                <form action="add.php" method="post" enctype="multipart/form-data">
                    <h3 class="text-center my-4 h1">ADD NEW</h3>

                    <input type="hidden" name="id" value="<?php echo $id ?>">

                    <div class="form-group my-3">
                        <label for="project" class="fw-bold my-1">Project Name: </label>
                        <input name="project" value="<?php echo $project ?>" type="text" class="form-control" id="project" placeholder="Enter Project">
                    </div>

                    <div class="form-group my-3">
                        <label for="transaction" class="fw-bold my-1">Transaction Type: </label>
                        <div class="d-flex gap-3 ">

                            <div class="form-check">
                                <input class="form-check-input" value="online" type="radio" name="transaction" id="online" <?php

                                                                                                                            if ($transaction === 'online') {
                                                                                                                                echo 'checked';
                                                                                                                            }

                                                                                                                            ?>>
                                <label class="form-check-label" for="online">
                                    Online
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" value="offline" type="radio" name="transaction" id="offline" <?php

                                                                                                                                if ($transaction === 'offline') {
                                                                                                                                    echo 'checked';
                                                                                                                                }

                                                                                                                                ?>>
                                <label class="form-check-label" for="offline">
                                    Offline
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group my-3">
                        <label for="income" class="fw-bold my-1">Income Source: </label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" name="income" type="radio" value="personal" id="personal" <?php

                                                                                                                            if ($income === 'personal') {
                                                                                                                                echo 'checked';
                                                                                                                            }

                                                                                                                            ?>>
                                <label class="form-check-label" for="personal">
                                    Personal
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="income" type="radio" value="business" id="business" <?php

                                                                                                                            if ($income === 'business') {
                                                                                                                                echo 'checked';
                                                                                                                            }

                                                                                                                            ?>>
                                <label class="form-check-label" for="business">
                                    Business
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group my-3">
                        <label for="amount" class="fw-bold my-1">Amount: </label>
                        <input value="<?php echo $amount ?>" name="amount" type="text" class="form-control" id="amount" placeholder="Enter Amount">
                    </div>

                    <div class="form-group my-3">
                        <label for="currency" class="fw-bold my-1">Currency: </label>
                        <div class="d-flex gap-3">
                            <div class="form-check">
                                <input class="form-check-input" value="usd" type="radio" name="currency" id="usd" <?php

                                                                                                                    if ($currency === 'usd') {
                                                                                                                        echo 'checked';
                                                                                                                    }

                                                                                                                    ?>>
                                <label class="form-check-label" for="usd">
                                    USD
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" value="eur" type="radio" name="currency" id="eur" <?php

                                                                                                                    if ($currency === 'eur') {
                                                                                                                        echo 'checked';
                                                                                                                    }

                                                                                                                    ?>>
                                <label class="form-check-label" for="eur">
                                    EUR
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" value="gbp" type="radio" name="currency" id="gbp" <?php

                                                                                                                    if ($currency === 'gbp') {
                                                                                                                        echo 'checked';
                                                                                                                    }

                                                                                                                    ?>>
                                <label class="form-check-label" for="gbp">
                                    GBP
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" value="cad" type="radio" name="currency" id="cad" <?php

                                                                                                                    if ($currency === 'cad') {
                                                                                                                        echo 'checked';
                                                                                                                    }

                                                                                                                    ?>>
                                <label class="form-check-label" for="cad">
                                    CAD
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group my-3">
                        <button type="submit" name="submit" class="btn btn-primary" href="#" role="button">Submit</button>
                        <a name="" id="" class="btn btn-success" href="index.php" role="button">Home</a>
                    </div>


                </form>
            </div>
        </div>
    </div>

    <!--Add boostrap stript links add here-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</body>

</html>